var express = require('express');
var app = express();
var request = require('request');

var port = process.env.PORT || 3000;

app.get('/', function(req, res) {
    res.end("Welcome!");
});

app.get('/query', function(req, res){
    // res.send('id: ' + req.query.id);
    var request_url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=' + req.query.symbol + '&outputsize=full&apikey=QTAX2CXFZ8AQE95Z';
    request(request_url).pipe(res);
});

app.listen(port);
console.log("listening port " + port);

// eg: https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=MSFT&outputsize=full&apikey=QTAX2CXFZ8AQE95Z